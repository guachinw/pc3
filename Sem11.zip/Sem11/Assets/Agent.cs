﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Agent : SBAgent
{
    int index = 4;
    int target;


    List<int> Targets = new List<int>();
    int r = -1;
    // Start is called before the first frame update
    void Start()
    {
        Targets.Add(0);
        Targets.Add(1);
        Targets.Add(3);
        //index = Random.Range(0, 5);
        //Targets = PathFinding.Disjkstra(Global.map, 0, 2);
        transform.position = GameObject.Find("p" + index).GetComponent<Transform>().position;
        TargetChange();
    }

    // Update is called once per frame
    void Update()
    {
        //velocity += SteeringBehaviours.Arrive(this, GameObject.Find("p" + target).GetComponent<Transform>(), 1);
        velocity += SteeringBehaviours.Seek(this, GameObject.Find("p" + Targets[target]).GetComponent<Transform>());

        if (Vector3.Distance(transform.position, GameObject.Find("p" + target).GetComponent<Transform>().position) <= 0.01f){
            index = target;
            TargetChange();
        }

        transform.position += velocity * Time.deltaTime;
    }

    void TargetChange()
    {
        /*   int r = Random.Range(0, 5);

           while (Global.map[index, r] == -1)
           {
               r = Random.Range(0, 5);
           }

           target = r;*/

        r += 1;

        if (r == 3)
        {
            r--;
        }


        target = r;
    }
}
