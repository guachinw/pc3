﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnDrawGizmos()
    {
        Gizmos.color = Color.cyan;
        for (int i = 0; i < 5; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                if (Global.map[i,j] != -1 )
                {
                    Vector3 pI = GameObject.Find("p" + i).transform.position;
                    Vector3 pF = GameObject.Find("p" + j).transform.position;
                    Gizmos.DrawLine(pI, pF);
                }

            }
        }
    }
}
