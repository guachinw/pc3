﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Global
{
    static public  int[,] map = {
        {-1, 2, -1, 3,  4},
        {2, -1, 1, -1, 5},
        {-1, 1, -1, -1, -1},
        {3, -1, -1, -1, -1},
        {4,5,-1,-1,-1 }
        };
}
