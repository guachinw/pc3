﻿using UnityEngine;

public class SBAgent : MonoBehaviour
{
    public Vector3 velocity = Vector3.zero;
    public float maxSteer = 5;
    public float maxSpeed = 10;
    Vector3 desired;
    Vector3 steer;
}
